<?php
define("base_url", "http://localhost/clase/workspace/php_mysql_tShirt_onlineStore_Project/master-php/");
define("controller_default", "productoController");
define("action_default", "index");

